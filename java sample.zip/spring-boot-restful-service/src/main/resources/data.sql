insert into user values(10001, sysdate(), 'Alice');
insert into user values(10002, sysdate(), 'Lincy');
insert into user values(10003, sysdate(), 'Bob');

insert into post values(11001,'My First post', sysdate(), 10001);
insert into post values(11002,'My Second post', sysdate(), 10001);