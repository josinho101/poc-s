package com.josinho.rest.services.dao;

import org.springframework.stereotype.Component;

@Component
public class PostsDaoService {
}
